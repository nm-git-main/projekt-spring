package pl.sdacademy.projektspring.service;

import org.springframework.stereotype.Service;
import pl.sdacademy.projektspring.model.Product;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

@Service
public class ProductService {
    private final Map< Integer, Product> data = new HashMap<>();

    public ProductService() {
        data.put(1,new Product("Marchewka bio z wolnego wybiegu",9.99));
        data.put(2,new Product("Kapusta kiszona",5.50));
        data.put(3,new Product("Czosnek",3.78));
        data.put(4,new Product("Jablka",5.99));
        data.put(5,new Product("Cebula",0.99));
    }

    public Product findById (Integer id){

        return data.get(id);

    }
}

