package pl.sdacademy.projektspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjektSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
